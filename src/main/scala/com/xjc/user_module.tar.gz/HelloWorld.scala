import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import com.xjc.utils.TimeUtils

object test extends App {

    val conf = new SparkConf().setAppName("test")
    val sc = new SparkContext(conf)
    val months0 = TimeUtils.getNmonthsAgo(0)

    val file = sc.textFile(s"hdfs://Namenode01.Hadoop:9000/user/hive/warehouse/dwd.db/i_t_order/statmonth=$months0")
    val wordRdd = file.flatMap(_.split(" ")).flatMap(_.split("\t")).flatMap(_.split("\001"))
    //val wordCount = wordRdd.map(a=>(a,1)).reduceByKey(_+_).map((a,b)=>(b,a)).sortByKey()
    val wordCount = wordRdd.map(a=>(a,1)).reduceByKey(_+_)

    println(wordCount)
    //wordCount.saveAsTextFile("hdfs://Namenode01.Hadoop:9000/user/hive/warehouse/tmp.db/t20160317_1/result/")

    sc.stop()
}
